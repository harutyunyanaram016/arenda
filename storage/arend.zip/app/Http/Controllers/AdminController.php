<?php

namespace App\Http\Controllers;

use App\Http\Requests\CategoryRequest;
use App\Http\Requests\ServiceRequest;
use App\SubCategory;
use Illuminate\Http\Request;
use App\Category;
use App\Service;
use App\User;
use Illuminate\Support\Facades\Auth;
use Validator;

class AdminController extends Controller
{
    public function categories(){
        $sub_categories = SubCategory::all();
        $categories = Category::all();
        $page['cat'] = $categories;
        $page['subCat'] = $sub_categories;
        $page['title'] = 'Каталог техники';
        return view('admin.categories',compact('page'));
    }

    public function categoriesEdit($id, CategoryRequest $request){
        $subCat = SubCategory::find($id);
        if($request->isMethod('delete')){
            $subCat->delete();
            return redirect(route('categories'))->with('status','Price removed');
        }
    }

    public function services(){
        $services = Service::all();
        $page['services'] = $services;
        $page['title'] = 'Услуги';
        return view('admin.services',compact('page'));
    }

    public function editServices($id, Request $request)
    {
        $servise = Service::find($id);
        if ($servise) {

            if ($request->isMethod('delete')) {
                if($servise->delete()){
                    return 'true';
                }
            }
            if ($request->isMethod('post')) {
                $input = $request->except('_token');
                $validator = Validator:: make($input, [
                    'name' => 'required|max:255',
                    'link' => 'required|unique:services,link,' . $request->id
                ]);
                $servise->name = $input['name'];
                $servise->link = $input['link'];
                $servise->content = $input['text'];
                $servise->price = $input['price'];
                if($servise->update()){
                    return redirect(route('services'))->with('status','Услуга обновлена');
                }
                return redirect(route('servicesEdit',['sevice'=>$id]));

            }
            $page['title'] = 'Изминить услугу';
            $page['service'] = $servise;
            return view('admin.editSevice', compact('page'));
        }
    }

    public function addServices(Request $request){

        if ($request->isMethod('post')) {
            $service = new Service();
            $input = $request->except('_token');
            $validator = Validator:: make($input, [
                'name' => 'required|max:255',
                'link' => 'required|unique:services,link,' . $request->id
            ]);
            $service->name = $input['name'];
            $service->link = $input['link'];
            $service->content = $input['text'];
            $service->price = $input['price'];
            if($service->save()){
                return redirect(route('services'))->with('status','Услуга добавлена');
            }
        }
        $page['title'] = 'Добавить услугу';
        return view('admin.addService', compact('page'));

    }

    public function addCategory(Request $request){
        if ($request->isMethod('post')) {
            $category = new SubCategory();
            $input = $request->except('_token');
            $validator = Validator:: make($input, [
                'name' => 'required|max:255',
                'link' => 'required|unique:categories,link,' . $request->id
            ]);
//            var_dump($input);die;
            $category->name = $input['name'];
            $category->link = $input['link'];
            $category->content = $input['text'];
            $category->price = $input['price'];
            $category->category_id = $input['category_id'];
            if($category->save()){
                return redirect(route('categories'))->with('status','Услуга добавлена');
            }

        }
        $categories = Category::all();
        $cat = array();
        foreach ($categories as $category){
            $cat[$category->id] = $category->name;
        }
        $page['cat'] = $cat;
        $page['title'] = 'Добавить технику';
        return view('admin.addCategory', compact('page'));

    }

    public function editCategory($id, Request $request){
        $subCategory = SubCategory::find($id);
        if($request->isMethod('delete')){
            if($subCategory->delete()){
                return 'true';
            }
        }
        if ($request->isMethod('post')) {
            $input = $request->except('_token');
            $validator = Validator:: make($input, [
                'name' => 'required|max:255',
                'link' => 'required|unique:categories,link,' . $request->id
            ]);
//            var_dump($input);die;
            $subCategory->name = $input['name'];
            $subCategory->link = $input['link'];
            $subCategory->content = $input['text'];
            $subCategory->price = $input['price'];
            $subCategory->category_id = $input['category_id'];
            if($subCategory->update()){
                return redirect(route('categories'))->with('status','Услуга добавлена');
            }

        }
        $categories = Category::all();
        $cat = array();
        foreach ($categories as $category){
            $cat[$category->id] = $category->name;
        }
        $page['cat'] = $cat;
        $page['sub'] = $subCategory;
        $page['title'] = 'Изминить технику';
        return view('admin.editCategory', compact('page'));

    }

}
