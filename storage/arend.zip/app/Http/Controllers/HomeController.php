<?php

namespace App\Http\Controllers;

use App\SubCategory;
use Illuminate\Http\Request;
use App\Category;
use App\Service;
use App\Http\Controllers\MenuController;

class HomeController extends Controller
{
    public function index(){
        $allServise = Service::get(['name','link']);
        $page['allServise'] = $allServise;
        $page['menu'] = MenuController::getMenu();
        $page['title'] = "Главная";
        return view('home1', compact('page'));

    }
    public function contact(){
        $allServise = Service::get(['name','link']);
        $page['menu'] = MenuController::getMenu();
        $page['allServise'] = $allServise;
        $page['title'] = "» Контакты";
        return view('contact', compact('page'));
    }
    public function priceList(){
        $allServise = Service::get(['name','link']);
        $page['menu'] = MenuController::getMenu();
        $page['allServise'] = $allServise;
        $page['title'] = " » Прайс лист";
        return view('lists', compact('page'));
    }
    public function error(){
        $allServise = Service::get(['name','link']);
        $page['menu'] = MenuController::getMenu();
        $page['allServise'] = $allServise;
        $page['title'] = "Error";
        return view('error', compact('page'));
    }
}
