<?php

namespace App\Http\Controllers;
use App\Category;
use App\SubCategory;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    public static function getMenu(){
        $categories = Category::all();
        $menus = array();
        foreach ($categories as $category){
            $menu['name']=$category->name;
            $menu['link']=$category->link;
            $menu['sub_cat']=SubCategory::where('category_id',$category->id)->get(['name','link']);
            $menus[] = $menu;
        }

        return $menus;
    }
}
