@extends('layout',  array('title'=>$page['title'], 'allServise'=>$page['allServise'], 'menus'=>$page['menu']))
@section('content')
    <h1>Ошибка 404. "Страница не найдена" </h1>
@endsection