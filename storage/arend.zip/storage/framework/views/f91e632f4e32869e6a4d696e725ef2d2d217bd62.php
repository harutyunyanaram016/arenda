<!DOCTYPE html>


<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

    <meta name="yandex-verification" content="76108bafa555283c" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title><?php echo e($title); ?> </title>

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <link rel="icon" type="image/x-icon" href="<?php echo e(route('home')); ?>/favicon.ico" />
    <script type="text/javascript" src="<?php echo asset('js/jquery.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('js/parallax.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('js/js.js'); ?>"></script>


</head>
<body class="header_min">

<div class="over">

    <div class="overlay"></div>
    <div class="popup">
        <div class="close">X</div>
        <div class="popup_form">
            <p>Заказать звонок</p>
            <form id="form" method="post" action="35-katok.html">
                <input type="text" name="name" id="name" placeholder="Ваше имя" onfocus="$(this).attr('placeholder', '')" onblur="$(this).attr('placeholder', 'Ваше имя')"/>
                <input type="text" name="phone" id="phone" placeholder="Ваш телефон" onfocus="$(this).attr('placeholder', '')" onblur="$(this).attr('placeholder', 'Ваш телефон')" required/>
                <input type="hidden" name="usl" class="usl">
                <span><input type="checkbox" name="policy" required ><a href="<?php echo e(route('home')); ?>/index.html%3Fpage_id=180&amp;preview=true.html" target="_blank" title="">Соглашение об использовании веб-сайта</a></span>
                <input type="submit" id="submit" value="Отправить"/>
                <!-- <input type="submit" id="submit" value="Отправить" onclick="yaCounter45440928.reachGoal('zakaz'); return true;"/> -->
            </form>
        </div>
    </div>

    <div class="header">
        <div class="logo">
            <a href="<?php echo e(route('home')); ?>" title="">АвтоСпецТехника</a>
            <div class="slogan">
                <span>аренда в Омске</span>
            </div>
        </div>

        <div class="main_menu">
            <ul id = "menu-main_menu" class = "menu">
                <li id="menu-item-77" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-77">
                    <a href="<?php echo e(route('home')); ?>">Главная</a>
                </li>
                <li id="menu-item-64" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-64">
                    <a href="<?php echo e(route('contact')); ?>">Контакты</a>
                </li>
                <li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67">
                    <a href="<?php echo e(route('price-list')); ?>">Прайс лист</a>
                </li>
                <?php if(Auth::user()): ?>
                    <li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67">
                        <a href="<?php echo e(route('categories')); ?>">Панель управления</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="telefon">
            8 (3812) 98 40 48<br />
            8 983 568 40 48<br />
            <a href="mailto:spectehneka@mail.ru" title="">spectehneka@mail.ru</a>
        </div>

        <div class="call">
            ЗАКАЗАТЬ
        </div>

    </div>


    <div class="main_block">
        <div data-offset="0" class="poster">
            <div class="ekskol_cont">
                <div data-offset="50" class="layer-1 landscape1">
                    <div class="ekskol"></div>
                </div>
            </div>
            <div data-offset="0"  class="layer-2 yellow">

            </div>
            <div class="call">
                ЗАКАЗАТЬ
            </div>
            <div class="kovsh_cont">
                <div data-offset="50" class="layer-4 landscape1">
                    <div class="kovsh_shadow"><img src="<?php echo e(route('home')); ?>/css/images/kovsh_shadow.png" alt=""/></div>
                </div>
            </div>
            <div data-offset="0" class="layer-3 ramka"></div>
            <div data-offset="50" class="layer-4 landscape1">
                <div class="kovsh"><img src="<?php echo e(route('home')); ?>/css/images/kovsh.png" alt=""/></div>
            </div>
            <div data-offset="20" class="layer-5 dust"></div>
        </div>
    </div>

    <div class="left">
        <div class="left_height">
            <div class="menu_cat">
                <div class="left_titile">
                    Каталог техники
                </div>
                <ul>
                    <li><a href="35-katok.html#">Дорожная техника</a>
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>/dorozhnostroitelnaya-tehnika/arenda-mksm-mini-pogruzchik-bobket">Аренда МКСМ/ Мини погрузчик Бобкэт</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/dorozhnostroitelnaya-tehnika/greyder.html">Грейдер</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/dorozhnostroitelnaya-tehnika/katok.html">Каток</a></li>
                        </ul>								</li>
                    <li><a href="35-katok.html#">Землеройная</a>
                        <ul>											<li><a href="<?php echo e(route('home')); ?>/zemleroynaya/41-arenda-ekskavatora-v-omske.html">Аренда экскаватора в омске</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/zemleroynaya/29-yamobur-buroyam-bkm.html">Ямобур/Буроям (БКМ)</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/zemleroynaya/9-buldozer.html">Аренда бульдозера в Омске</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/zemleroynaya/8-frontalnyy-pogruzchik.html">Фронтальный погрузчик</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/zemleroynaya/7-ekskavtor-pogruzchik.html">Экскаватор-погрузчик</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/zemleroynaya/6-ekskavator.html">Аренда экскаватора в Омске</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/zemleroynaya/5-arenda-bary.html">Аренда бары</a></li>
                        </ul>								</li>
                    <li><a href="35-katok.html#">Подъемно-транспортная</a>
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>/podemno-transportnaya/44-avtovyshka-v-omske.html">Автовышка в омске</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/podemno-transportnaya/40-zakazat-kran-v-omske.html">Заказать кран в омске</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/podemno-transportnaya/12-avtovyshka-gidromanipulyator-14m-26m.html">Автовышка/гидроподъемник/мех.рука 14м-30м</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/podemno-transportnaya/11-samopogruzchika-vorovayka-5t-3t-12t-3t-12t-6t.html">Услуги самопогрузчика (воровайка) в Омске  5т/3т, 12т/3т, 12т/6т</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/podemno-transportnaya/10-avtokran.html">Автокран</a></li>
                        </ul>								</li>
                    <li><a href="35-katok.html#">Прочая техника</a>
                        <ul>											<li><a href="<?php echo e(route('home')); ?>/prochaya-tehnika/34-ilososnaya-mashina.html">Илососная машина</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/prochaya-tehnika/32-kompressor.html">Компрессор</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/prochaya-tehnika/16-traktora-so-schetkoy.html">Трактора с щеткой</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/prochaya-tehnika/15-a-s-bochka.html">А/С бочка</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/prochaya-tehnika/14-gidromolot.html">Гидромолот</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/prochaya-tehnika/13-betnonasos-shteter.html">Бетононасос/штетер</a></li>
                        </ul>								</li>
                    <li><a href="35-katok.html#">Транспортные машины</a>
                        <ul>											<li><a href="<?php echo e(route('home')); ?>/transportnye-mashiny/39-arenda-avtobetonosmesitel-uslugi-miksera.html">Аренда автобетоносмеситель/ услуги миксера</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/transportnye-mashiny/26-samosval-5t-25t.html">Аренда самосвала</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/transportnye-mashiny/25-sedelnyy-tyagach-s-polupricepom-9m-13m.html">Седельный тягач с полуприцепом (9м-13м)</a></li>
                            <li><a href="<?php echo e(route('home')); ?>/transportnye-mashiny/24-nizko-ramnyy-tral.html">Низкорамный трал</a></li>
                        </ul>								</li>
                </ul>
            </div>

            <div class="menu_cat">

                <div class="left_titile">
                    Услуги
                </div>
                <ul>
                    <?php $__currentLoopData = $allServise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('home')); ?>/uslugi/<?php echo e($item->link); ?>"><?php echo e($item->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>


        <div class="skroll_bl">
            <section id="title_portf" data-speed="0" data-type="background" style="background: url(<?php echo e(route('home')); ?>/css/images/skroll_bl.jpg) 0 0 no-repeat fixed;">

                <div class="metr">
                    <!-- Yandex.Metrika informer -->
                    <a href="https://metrika.yandex.ru/stat/?id=45440928&amp;from=informer"
                       target="_blank" rel="nofollow"><img src="https://informer.yandex.ru/informer/45440928/3_0_FFFFFFFF_EFEFEFFF_0_pageviews"
                                                           style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" class="ym-advanced-informer" data-cid="45440928" data-lang="ru" /></a>
                    <!-- /Yandex.Metrika informer -->

                    <!-- Yandex.Metrika counter -->
                    <script type="text/javascript" >
                        (function (d, w, c) {
                            (w[c] = w[c] || []).push(function() {
                                try {
                                    w.yaCounter45440928 = new Ya.Metrika({
                                        id:45440928,
                                        clickmap:true,
                                        trackLinks:true,
                                        accurateTrackBounce:true,
                                        webvisor:true
                                    });
                                } catch(e) { }
                            });

                            var n = d.getElementsByTagName("script")[0],
                                s = d.createElement("script"),
                                f = function () { n.parentNode.insertBefore(s, n); };
                            s.type = "text/javascript";
                            s.async = true;
                            s.src = "https://mc.yandex.ru/metrika/watch.js";

                            if (w.opera == "[object Opera]") {
                                d.addEventListener("DOMContentLoaded", f, false);
                            } else { f(); }
                        })(document, window, "yandex_metrika_callbacks");
                    </script>
                    <noscript><div><img src="https://mc.yandex.ru/watch/45440928" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
                    <!-- /Yandex.Metrika counter -->
                </div>

                <div class="logo2">
                    АвтоСпецТехника
                    <span>Аренда спецтехники в Омске</span>
                </div>
                <div class="razrab">
                    <a href="http://Oceanweb.ru/" target="_blank" title="">
                        <span>Сделано в</span>
                        Oceanweb.ru
                    </a>
                </div>
            </section>
        </div>
    </div>


    <div class="right">

        <div class="vnutr_text">
            <h1>Аренда МКСМ/ Мини погрузчик Бобкэт</h1>


            <div class="cena">
                <p>
                    <?php if($price > 0): ?>
                        от <?php echo e($price); ?> рублей
                    <?php endif; ?>
                </p>
                <div class="call">
                    ЗАКАЗАТЬ
                </div>
            </div>

            <div class="contacts">
                <span>Звоните нам</span>
                <p>8 (3812) 98 40 48</p>
                <p>8 983 568 40 48</p>
            </div>


            <div class="icons">
                <div class="icons_res">
                    <div class="icons_bl">
                        <div class="icons_img">
                            <img src="<?php echo e(route('home')); ?>/images/ic_1.svg" alt=""/>
                        </div>
                        <div class="icons_text">
                            Надежная, исправная техника
                        </div>
                    </div>
                </div>
                <div class="icons_res">
                    <div class="icons_bl">
                        <div class="icons_img">
                            <img src="<?php echo e(route('home')); ?>/images/ic_3.svg" alt=""/>
                        </div>
                        <div class="icons_text">
                            Ответственные и опытные исполнители
                        </div>
                    </div>
                </div>
                <div class="icons_res">
                    <div class="icons_bl">
                        <div class="icons_img">
                            <img src="<?php echo e(route('home')); ?>/images/ic_2.svg" alt=""/>
                        </div>
                        <div class="icons_text">
                            Заключение договора
                        </div>
                    </div>
                </div>
                <div class="icons_res">
                    <div class="icons_bl">
                        <div class="icons_img">
                            <img src="<?php echo e(route('home')); ?>/images/ic_4.svg" alt=""/>
                        </div>
                        <div class="icons_text">
                            Бережный и аккуратный подход
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab_click">
                <div class="tab_over">
                    <div class="tab_text">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>

        </div>

        <div class="vk">
            <script type="text/javascript" src="http://vk.com/js/api/openapi.js?121"></script>

            <!-- VK Widget -->
            <div id="vk_groups"></div>
            <script type="text/javascript">
                VK.Widgets.Group("vk_groups", {mode: 0, width: "680", height: "200", color1: 'FFFFFF', color2: '2B587A', color3: '5B7FA6'}, 68167880);
            </script>
        </div>

    </div>







</div>

<!-- PARALLAX-POSTER -->
<script src="<?php echo e(route('home')); ?>/js/parallax-poster.js"></script>


<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-103431672-1', 'auto');
    ga('send', 'pageview');

</script>

</body>
</html>