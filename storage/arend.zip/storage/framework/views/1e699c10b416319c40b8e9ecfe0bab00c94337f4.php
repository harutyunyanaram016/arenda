<?php $__env->startSection('content'); ?>
    <h2><?php echo e($page['title']); ?></h2>
    <?php if(isset($status)): ?>
        <p>
            <?php echo e($status); ?>


        </p>
    <?php endif; ?>

    <div class="wrapper container-fluid">

        <div class="content col-md-10 col-md-offset-1">

            <?php echo Form::open(['url'=>route('servicesAdd'), 'method'=>'POST', 'class'=>'form-horizontal','enctype'=>'multipart/form-data']); ?>



            <div class="form-group">
                <?php echo Form::label('name','Имя',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::text('name','',['class'=>'form-control','placeholder'=>'Имя']); ?>

                </div>

            </div>


            <div class="form-group">

                <?php echo Form::label('alias','Ссылка',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::text('link','',['class'=>'form-control','placeholder'=>'Ссылка']); ?>

                </div>

            </div>

            <div class="form-group">

                <?php echo Form::label('alias','Цена',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::number('price','',['class'=>'form-control','placeholder'=>'Цена']); ?>

                </div>

            </div>


            <div class="form-group">

                <?php echo Form::label('text','Описание',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::textarea('text','',['id'=>'editor','class'=>'form-control']); ?>

                </div>

            </div>
            <div class="form-group">

                
                
                    
                    
                

            </div>
            <div class="form-group">

                
                
                    
                

            </div>


            <div class="form-group">
                <div class="col-md-offset-2 col-md-8">
                    <?php echo Form::button('Save',['class'=>'save btn btn-primary','type'=>'submit']); ?>

                </div>
            </div>


            <script>
                CKEDITOR.replace('editor');
            </script>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array('title'=>$page['title']), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>