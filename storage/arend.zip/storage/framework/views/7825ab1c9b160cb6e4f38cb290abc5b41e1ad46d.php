<?php $__env->startSection('content'); ?>
    <h1>Ошибка 404. "Страница не найдена" </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout',  array('title'=>$page['title'], 'allServise'=>$page['allServise']), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>