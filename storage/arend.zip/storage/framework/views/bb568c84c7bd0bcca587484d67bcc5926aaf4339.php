
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

    <meta name="yandex-verification" content="76108bafa555283c" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <link rel="stylesheet" type="text/css" href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/themes/spectech2/style.css" />

    <title></title>

    <link rel="icon" type="image/x-icon" href="favicon.ico" />

    <!-- БИБЛИОТЕКА -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.js"></script>

    <!-- JS -->
    <script src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/themes/spectech2/js/js.js"></script>

    <!-- PARALLAX -->
    <script src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/themes/spectech2/js/parallax.js"></script>


</head>
<body >

<div class="over">

    <div class="overlay"></div>
    <div class="popup">
        <div class="close">X</div>
        <div class="popup_form">
            <p>Заказать звонок</p>
            <form id="form" method="post" action="">
                <input type="text" name="name" id="name" placeholder="Ваше имя" onfocus="$(this).attr('placeholder', '')" onblur="$(this).attr('placeholder', 'Ваше имя')"/>
                <input type="text" name="phone" id="phone" placeholder="Ваш телефон" onfocus="$(this).attr('placeholder', '')" onblur="$(this).attr('placeholder', 'Ваш телефон')" required/>
                <input type="hidden" name="usl" class="usl">
                <span><input type="checkbox" name="policy" required ><a href="/?page_id=180&preview=true" target="_blank" title="">Соглашение об использовании веб-сайта</a></span>
                <input type="submit" id="submit" value="Отправить"/>
                <!-- <input type="submit" id="submit" value="Отправить" onclick="yaCounter45440928.reachGoal('zakaz'); return true;"/> -->
            </form>
        </div>
    </div>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".popup_form form").submit(function(){
                var res = true;

                setTimeout(function(){
                    $('#phone').removeClass('error');
                }, 3000);

                if($('#phone').val() === ''){
                    res = false
                    $('#phone').addClass('error');
                }

                var data = $(this).serialize() + '&action=siteWideMessage';
                if(res){
                    yaCounter45440928.reachGoal('zakaz');
                    $.post('http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-admin/admin-ajax.php', data, function(data){
                        setTimeout(function(){
                            $('.close').click();
                            $(".popup_form form").trigger('reset');
                            $(".popup_form form .usl").val('');
                        }, 1500);
                    });
                }

                return false;
            });
        });
    </script>


    <div class="header">
        <div class="logo">
            <a href="/" title="">АвтоСпецТехника</a>
            <div class="slogan">
                <span>аренда в Омске</span>
            </div>
        </div>

        <div class="main_menu">
            <ul id = "menu-main_menu" class = "menu"><li id="menu-item-77" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-77 act "><a href="/">Главная</a></li>
                <li id="menu-item-64" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-64"><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/kontakty">Контакты</a></li>
                <li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67"><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/prajs-list">Прайс лист</a></li>
            </ul>		</div>

        <div class="telefon">
            8 (3812) 98 40 48<br />
            8 983 568 40 48<br />
            <a href="mailto:spectehneka@mail.ru" title="">spectehneka@mail.ru</a>
        </div>

        <div class="call">
            ЗАКАЗАТЬ
        </div>

    </div>


    <div class="main_block">
        <div data-offset="0" class="poster">
            <div class="ekskol_cont">
                <div data-offset="50" class="layer-1 landscape1">
                    <div class="ekskol"></div>
                </div>
            </div>
            <div data-offset="0"  class="layer-2 yellow">

            </div>
            <div class="call">
                ЗАКАЗАТЬ
            </div>
            <div class="kovsh_cont">
                <div data-offset="50" class="layer-4 landscape1">
                    <div class="kovsh_shadow"><img src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/themes/spectech2/images/kovsh_shadow.png" alt=""/></div>
                </div>
            </div>
            <div data-offset="0" class="layer-3 ramka"></div>
            <div data-offset="50" class="layer-4 landscape1">
                <div class="kovsh"><img src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/themes/spectech2/images/kovsh.png" alt=""/></div>
            </div>
            <div data-offset="20" class="layer-5 dust"></div>
        </div>
    </div>


    <div class="left">
        <div class="left_height">
            <div class="menu_cat">
                <div class="left_titile">
                    Каталог техники
                </div>
                <ul>
                    <li><a href="#">Дорожная техника</a>
                        <ul>											<li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/dorozhnostroitelnaya-tehnika/38-arenda-mksm-mini-pogruzchik-bobket.html">Аренда МКСМ/ Мини погрузчик Бобкэт</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/dorozhnostroitelnaya-tehnika/36-greyder.html">Грейдер</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/dorozhnostroitelnaya-tehnika/35-katok.html">Каток</a></li>
                        </ul>								</li>
                    <li><a href="#">Землеройная</a>
                        <ul>											<li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/41-arenda-ekskavatora-v-omske.html">Аренда экскаватора в омске</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/29-yamobur-buroyam-bkm.html">Ямобур/Буроям (БКМ)</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/9-buldozer.html">Аренда бульдозера в Омске</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/8-frontalnyy-pogruzchik.html">Фронтальный погрузчик</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/7-ekskavtor-pogruzchik.html">Экскаватор-погрузчик</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/6-ekskavator.html">Аренда экскаватора в Омске</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/5-arenda-bary.html">Аренда бары</a></li>
                        </ul>								</li>
                    <li><a href="#">Подъемно-транспортная</a>
                        <ul>											<li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/44-avtovyshka-v-omske.html">Автовышка в омске</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/40-zakazat-kran-v-omske.html">Заказать кран в омске</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/12-avtovyshka-gidromanipulyator-14m-26m.html">Автовышка/гидроподъемник/мех.рука 14м-30м</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/11-samopogruzchika-vorovayka-5t-3t-12t-3t-12t-6t.html">Услуги самопогрузчика (воровайка) в Омске  5т/3т, 12т/3т, 12т/6т</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/10-avtokran.html">Автокран</a></li>
                        </ul>								</li>
                    <li><a href="#">Прочая техника</a>
                        <ul>											<li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/prochaya-tehnika/34-ilososnaya-mashina.html">Илососная машина</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/prochaya-tehnika/32-kompressor.html">Компрессор</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/prochaya-tehnika/16-traktora-so-schetkoy.html">Трактора с щеткой</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/prochaya-tehnika/15-a-s-bochka.html">А/С бочка</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/prochaya-tehnika/14-gidromolot.html">Гидромолот</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/prochaya-tehnika/13-betnonasos-shteter.html">Бетононасос/штетер</a></li>
                        </ul>								</li>
                    <li><a href="#">Транспортные машины</a>
                        <ul>											<li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/transportnye-mashiny/39-arenda-avtobetonosmesitel-uslugi-miksera.html">Аренда автобетоносмеситель/ услуги миксера</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/transportnye-mashiny/26-samosval-5t-25t.html">Аренда самосвала</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/transportnye-mashiny/25-sedelnyy-tyagach-s-polupricepom-9m-13m.html">Седельный тягач с полуприцепом (9м-13м)</a></li>
                            <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/transportnye-mashiny/24-nizko-ramnyy-tral.html">Низкорамный трал</a></li>
                        </ul>								</li>
                </ul>
            </div>

            <div class="menu_cat">

                <div class="left_titile">
                    Услуги
                </div>
                <ul>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/42-gruzoperevozki-v-omske.html">Грузоперевозки в омске</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/37-perevozka-negabarita.html">Перевозка негабарита</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/33-perevozka-metalicheskih-garazhey.html">Перевозка гаражей</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/28-bez-transheynaya-prokladka-kommunikaciy-gnb.html">Без траншейная прокладка коммуникаций/ГНБ</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/27-dostavka-peska-schebnya-uglya.html">ДОСТАВКА ПЕСКА, ЩЕБНЯ И БЕТОНА в ОМСКЕ</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/23-perevozka-peregon-tehniki.html">Перевозка/перегон техники</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/22-kvartirnyy-ofisnyy-pereezd.html">Квартирный/офисный переезд</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/21-perevozka-zh-b-garazhey-mylnic.html">Перевозка ж/б гаражей \&#187;мыльниц\&#187;</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/20-uborka-i-utilizaciya-stroitelnogo-musora.html">Уборка и утилизация строительного мусора</a></li>
                    <li><a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/uslugi/19-uborka-i-utilizaciya-snega.html">Уборка и утилизация снега</a></li>
                </ul>
            </div>
        </div>


        <div class="skroll_bl">
            <section id="title_portf" data-speed="0" data-type="background" style="background: url(http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/themes/spectech2/images/skroll_bl.jpg) 0 0 no-repeat fixed;">

                <div class="metr">
                    <!-- Yandex.Metrika informer -->
                    <a href="https://metrika.yandex.ru/stat/?id=45440928&amp;from=informer"
                       target="_blank" rel="nofollow"><img src="https://informer.yandex.ru/informer/45440928/3_0_FFFFFFFF_EFEFEFFF_0_pageviews"
                                                           style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" class="ym-advanced-informer" data-cid="45440928" data-lang="ru" /></a>
                    <!-- /Yandex.Metrika informer -->

                    <!-- Yandex.Metrika counter -->
                    <script type="text/javascript" >
                        (function (d, w, c) {
                            (w[c] = w[c] || []).push(function() {
                                try {
                                    w.yaCounter45440928 = new Ya.Metrika({
                                        id:45440928,
                                        clickmap:true,
                                        trackLinks:true,
                                        accurateTrackBounce:true,
                                        webvisor:true
                                    });
                                } catch(e) { }
                            });

                            var n = d.getElementsByTagName("script")[0],
                                s = d.createElement("script"),
                                f = function () { n.parentNode.insertBefore(s, n); };
                            s.type = "text/javascript";
                            s.async = true;
                            s.src = "https://mc.yandex.ru/metrika/watch.js";

                            if (w.opera == "[object Opera]") {
                                d.addEventListener("DOMContentLoaded", f, false);
                            } else { f(); }
                        })(document, window, "yandex_metrika_callbacks");
                    </script>
                    <noscript><div><img src="https://mc.yandex.ru/watch/45440928" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
                    <!-- /Yandex.Metrika counter -->
                </div>

                <div class="logo2">
                    АвтоСпецТехника
                    <span>Аренда спецтехники в Омске</span>
                </div>
                <div class="razrab">
                    <a href="http://Oceanweb.ru/" target="_blank" title="">
                        <span>Сделано в</span>
                        Oceanweb.ru
                    </a>
                </div>
            </section>
        </div>
    </div>


    <div class="right">

        <div class="titles">
            Часто заказываемые
        </div>

        <div class="bl_cont">

            <div class="bl_res">
                <div class="block">
                    <div class="block_padd">
                        <div class="block_img">
                            <img width="305" height="215" src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/autovychka_bg_01.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="autovychka_bg_01" srcset="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/autovychka_bg_01.jpg 305w, http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/autovychka_bg_01-300x211.jpg 300w" sizes="(max-width: 305px) 100vw, 305px" />						</div>
                    </div>
                    <div class="block_zakaz">
                        ЗАКАЗАТЬ
                    </div>
                    <div class="block_title">
                        <a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/44-avtovyshka-v-omske.html" title="">Автовышка в омске</a>
                    </div>
                </div>
            </div>



            <div class="bl_res">
                <div class="block">
                    <div class="block_padd">
                        <div class="block_img">
                            <img width="305" height="215" src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/excavator-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="excavator-1" srcset="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/excavator-1.jpg 305w, http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/excavator-1-300x211.jpg 300w" sizes="(max-width: 305px) 100vw, 305px" />						</div>
                    </div>
                    <div class="block_zakaz">
                        ЗАКАЗАТЬ
                    </div>
                    <div class="block_title">
                        <a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/zemleroynaya/41-arenda-ekskavatora-v-omske.html" title="">Аренда экскаватора в омске</a>
                    </div>
                </div>
            </div>



            <div class="bl_res">
                <div class="block">
                    <div class="block_padd">
                        <div class="block_img">
                            <img width="305" height="215" src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/1471517819277.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="1471517819277" srcset="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/1471517819277.jpg 305w, http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/uploads/2014/11/1471517819277-300x211.jpg 300w" sizes="(max-width: 305px) 100vw, 305px" />						</div>
                    </div>
                    <div class="block_zakaz">
                        ЗАКАЗАТЬ
                    </div>
                    <div class="block_title">
                        <a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/40-zakazat-kran-v-omske.html" title="">Заказать кран в омске</a>
                    </div>
                </div>
            </div>



            <div class="bl_res">
                <div class="block">
                    <div class="block_padd">
                        <div class="block_img">
                        </div>
                    </div>
                    <div class="block_zakaz">
                        ЗАКАЗАТЬ
                    </div>
                    <div class="block_title">
                        <a href="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/podemno-transportnaya/12-avtovyshka-gidromanipulyator-14m-26m.html" title="">Автовышка/гидроподъемник/мех.рука 14м-30м</a>
                    </div>
                </div>
            </div>





        </div>

        <div class="main_text">
            <p>Служба заказа и аренды «ООО АвтоСпецТехника» была основана 20 февраля 2005 года.<br />
                Наша компания оказывает услуги по аренде строительной, землеройной спецтехники и перевозке габаритных/негабаритных грузов. Нашими клиентами на сегодняшний день являются как крупные строительные и производственные компании Омска и Омской области, представители среднего и малого бизнеса, так и частные заказчики.<br />
                Автотранспорт и спецтехника базируются в нескольких районах г. Омска, что позволяет осуществить подачу до объекта с минимальной затратой времени. В случае непредвиденной ситуации, транспорт будет заменен максимально быстро.<br />
                Услуги аренды автоспецтехники в г.Омске могут быть предоставлены на любой интересующий Вас срок — от одного минимального заказа до нескольких месяцев и даже лет. Вся техника, представленная в нашем автопарке, имеет высокое качество и надежность, это гарантирует ее бесперебойную деятельность во время выполнения работ любого уровня сложности.</p>
            <p>В аренду спецтехники входит: предоставление техники, заправка техники ГСМ и работа машиниста.<br />
                Подробную информацию о стоимости перевозки, подборе нужного вида транспорта, доп., услугах Вам с удовольствием предоставят наши менеджеры. Произведут расчет стоимости перевозок, по области и России исходя из километража.<br />
                Для удобства наших клиентов мы предлагаем различные формы оплаты. Для корпоративных заказчиков предусмотрены скидки.<br />
                Экономьте свое время с нами! Зная только наш телефонный номер, Вы сможете полностью удовлетворить потребность во всех видах автотранспорта!<br />
                Для Вас работает команда профессионалов!</p>
            <p>P.S. Позвоните нам и убедитесь сами! Аренда спецтехники в Омске</p>
            <p>8 (3812) 98 40 48 и 8 983 568 40 48</p>
        </div>

        <div class="vk">
            <script type="text/javascript" src="//vk.com/js/api/openapi.js?121"></script>

            <!-- VK Widget -->
            <div id="vk_groups"></div>
            <script type="text/javascript">
                VK.Widgets.Group("vk_groups", {mode: 0, width: "680", height: "200", color1: 'FFFFFF', color2: '2B587A', color3: '5B7FA6'}, 68167880);
            </script>
        </div>


    </div>














</div>

<!-- PARALLAX-POSTER -->
<script src="http://xn--55-6kcajsays2aimzme3co.xn--p1ai/wp-content/themes/spectech2/js/parallax-poster.js"></script>


<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-103431672-1', 'auto');
    ga('send', 'pageview');

</script>

</body>
</html>