<?php $__env->startSection('content'); ?>
    <h2><?php echo e($page['title']); ?></h2>
    <?php if(isset($status)): ?>
        <p>
            <?php echo e($status); ?>


        </p>
    <?php endif; ?>

    <div class="wrapper container-fluid">

        <div class="content col-md-10 col-md-offset-1">

            <?php echo Form::open(['url'=>route('categoriesEdit',array('page'=>$page['sub']->id)), 'method'=>'POST', 'class'=>'form-horizontal','enctype'=>'multipart/form-data']); ?>



            <div class="form-group">
                <?php echo Form::label('name','Имя',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::text('name',$page['sub']['name'],['class'=>'form-control','placeholder'=>'Имя']); ?>

                </div>

            </div>


            <div class="form-group">

                <?php echo Form::label('alias','Ссылка',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::text('link',$page['sub']['link'],['class'=>'form-control','placeholder'=>'Ссылка']); ?>

                </div>

            </div>

            <div class="form-group">

                <?php echo Form::label('alias','Цена',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::number('price',$page['sub']['price'],['class'=>'form-control','placeholder'=>'Цена']); ?>

                </div>

            </div>

            <div class="form-group">

                <?php echo Form::label('category_id','Категория',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::select('category_id',$page['cat'],$page['sub']['category_id'],['class'=>'form-control']); ?>

                </div>

            </div>


            <div class="form-group">

                <?php echo Form::label('text','Описание',['class'=>'col-xs-2 control-label']); ?>

                <div class="col-xs-8">
                    <?php echo Form::textarea('text',$page['sub']['content'],['id'=>'editor','class'=>'form-control']); ?>

                </div>

            </div>
            <div class="form-group">

                
                
                    
                    
                

            </div>
            <div class="form-group">

                
                
                    
                

            </div>


            <div class="form-group">
                <div class="col-md-offset-2 col-md-8">
                    <?php echo Form::button('Save',['class'=>'save btn btn-primary','type'=>'submit']); ?>

                </div>
            </div>


            <script>
                CKEDITOR.replace('editor');
            </script>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array('title'=>$page['title']), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>