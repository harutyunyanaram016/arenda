
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

    <meta name="yandex-verification" content="76108bafa555283c" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <title><?php echo e($title); ?></title>

    <link rel="icon" type="image/x-icon" href="favicon.ico" />
    <script type="text/javascript" src="<?php echo asset('js/jquery.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('js/parallax.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('js/js.js'); ?>"></script>


</head>
<body >

<div class="over">

    <div class="overlay"></div>
    <div class="popup">
        <div class="close">X</div>
        <div class="popup_form">
            <p>Заказать звонок</p>
            <form id="form" method="post" action="">
                <input type="text" name="name" id="name" placeholder="Ваше имя" onfocus="$(this).attr('placeholder', '')" onblur="$(this).attr('placeholder', 'Ваше имя')"/>
                <input type="text" name="phone" id="phone" placeholder="Ваш телефон" onfocus="$(this).attr('placeholder', '')" onblur="$(this).attr('placeholder', 'Ваш телефон')" required/>
                <input type="hidden" name="usl" class="usl">
                <span><input type="checkbox" name="policy" required ><a href="/?page_id=180&preview=true" target="_blank" title="">Соглашение об использовании веб-сайта</a></span>
                <input type="submit" id="submit" value="Отправить"/>
                <!-- <input type="submit" id="submit" value="Отправить" onclick="yaCounter45440928.reachGoal('zakaz'); return true;"/> -->
            </form>
        </div>
    </div>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".popup_form form").submit(function(){
                var res = true;

                setTimeout(function(){
                    $('#phone').removeClass('error');
                }, 3000);

                if($('#phone').val() === ''){
                    res = false
                    $('#phone').addClass('error');
                }

                var data = $(this).serialize() + '&action=siteWideMessage';
                if(res){
                    yaCounter45440928.reachGoal('zakaz');
                    $.post('<?php echo e(route('home')); ?>/wp-admin/admin-ajax.php', data, function(data){
                        setTimeout(function(){
                            $('.close').click();
                            $(".popup_form form").trigger('reset');
                            $(".popup_form form .usl").val('');
                        }, 1500);
                    });
                }

                return false;
            });
        });
    </script>


    <div class="header">
        <div class="logo">
            <a href="/" title="">АвтоСпецТехника</a>
            <div class="slogan">
                <span>аренда в Омске</span>
            </div>
        </div>

        <div class="main_menu">
            <ul id = "menu-main_menu" class = "menu">
                <li id="menu-item-77" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-77 act ">
                    <a href="<?php echo e(route('home')); ?>">Главная</a>
                </li>
                <li id="menu-item-64" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-64">
                    <a href="<?php echo e(route('contact')); ?>">Контакты</a>
                </li>
                <li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67">
                    <a href="<?php echo e(route('price-list')); ?>">Прайс лист</a>
                </li>
            </ul>
        </div>

        <div class="telefon">
            8 (3812) 98 40 48<br />
            8 983 568 40 48<br />
            <a href="mailto:spectehneka@mail.ru" title="">spectehneka@mail.ru</a>
        </div>

        <div class="call">
            ЗАКАЗАТЬ
        </div>

    </div>


    <div class="main_block">
        <div data-offset="0" class="poster">
            <div class="ekskol_cont">
                <div data-offset="50" class="layer-1 landscape1">
                    <div class="ekskol"></div>
                </div>
            </div>
            <div data-offset="0"  class="layer-2 yellow">

            </div>
            <div class="call">
                ЗАКАЗАТЬ
            </div>
            <div class="kovsh_cont">
                <div data-offset="50" class="layer-4 landscape1">
                    <div class="kovsh_shadow"><img src="<?php echo e(route('home')); ?>/images/kovsh_shadow.png" alt=""/></div>
                </div>
            </div>
            <div data-offset="0" class="layer-3 ramka"></div>
            <div data-offset="50" class="layer-4 landscape1">
                <div class="kovsh"><img src="<?php echo e(route('home')); ?>/images/kovsh.png" alt=""/></div>
            </div>
            <div data-offset="20" class="layer-5 dust"></div>
        </div>
    </div>


    <div class="left">
        <div class="left_height">
            <div class="menu_cat">
                <div class="left_titile">
                    Каталог техники
                </div>

                <ul>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><a href="#"><?php echo e($menu['name']); ?></a>
                        <ul>


                            <?php $__currentLoopData = $menu['sub_cat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('home')); ?>/<?php echo e($menu['link']); ?>/<?php echo e($sub_cat->link); ?>"><?php echo e($sub_cat->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="menu_cat">

                <div class="left_titile">
                    Услуги
                </div>
                <ul>
                    <?php $__currentLoopData = $allServise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('home')); ?>/uslugi/<?php echo e($item->link); ?>"><?php echo e($item->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>


        <div class="skroll_bl">
            <section id="title_portf" data-speed="0" data-type="background" style="background: url(<?php echo e(route('home')); ?>/images/skroll_bl.jpg) 0 0 no-repeat fixed;">

                
                    
                    
                       
                                                           
                    

                    
                    
                        
                            
                                
                                    
                                        
                                        
                                        
                                        
                                        
                                    
                                
                            

                            
                                
                                
                            
                            
                            

                            
                                
                            
                        
                    
                    
                    
                

                <div class="logo2">
                    АвтоСпецТехника
                    <span>Аренда спецтехники в Омске</span>
                </div>
                <div class="razrab">
                    <a href="http://Oceanweb.ru/" target="_blank" title="">
                        <span>Сделано в</span>
                        Oceanweb.ru
                    </a>
                </div>
            </section>
        </div>
    </div>


    <div class="right">

        <?php echo $__env->yieldContent('content'); ?>

        <div class="vk">
            <script type="text/javascript" src="//vk.com/js/api/openapi.js?121"></script>

            <!-- VK Widget -->
            <div id="vk_groups"></div>
            <script type="text/javascript">
                VK.Widgets.Group("vk_groups", {mode: 0, width: "680", height: "200", color1: 'FFFFFF', color2: '2B587A', color3: '5B7FA6'}, 68167880);
            </script>
        </div>


    </div>














</div>

<!-- PARALLAX-POSTER -->
<script src="<?php echo e(route('home')); ?>/js/parallax-poster.js"></script>


<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-103431672-1', 'auto');
    ga('send', 'pageview');

</script>

</body>
</html>