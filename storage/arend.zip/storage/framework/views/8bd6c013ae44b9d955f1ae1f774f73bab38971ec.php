<?php $__env->startSection('content'); ?>
    <h2><?php echo e($page['title']); ?></h2>
    <?php if(isset($status)): ?>
    <p>


    </p>
    <?php endif; ?>
    <div>
        <a href="<?php echo e(route('categoriesAdd')); ?>"><button class="btn-primary" >Добавить технику</button></a>
    </div>
    <table class="table">
        <thead>
        <tr>
            <th>#</th>
            <th>Имя</th>
            <th>Ссылка</th>
            <th>Цена</th>
            <th>Категория</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $page['subCat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($sub->id); ?></td>
            <td><?php echo e($sub->name); ?></td>
            <td><?php echo e($sub->link); ?></td>
            <td><?php echo e($sub->price); ?></td>
            <td>
                <?php $__currentLoopData = $page['cat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sub->category_id == $cat->id): ?>
                        <?php echo e($cat->name); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>

                <a href="<?php echo e(route('categoriesEdit',['sevice'=>$sub->id])); ?>" class="cat-edit"><span class="glyphicon glyphicon-edit"></span></a>
                <a href="javascript:void(0)" class="cat-delete"> <span class="glyphicon glyphicon-remove"></span></a></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array('title'=>$page['title']), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>