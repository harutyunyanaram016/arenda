<?php $__env->startSection('content'); ?>
   <?php echo $page['content']; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('uslugi.layout',  array('title'=>$page['title'],'price'=>$page['price'], 'allServise'=>$page['allServise'], 'menus'=>$page['menu']), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>